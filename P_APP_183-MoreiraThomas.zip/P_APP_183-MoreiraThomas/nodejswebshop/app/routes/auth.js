const express = require("express");
const router = express.Router();
const controller = require("../controllers/AuthController");

router.get("/", controller.get);

router.get("/login", controller.get);
router.post("/login", controller.checkUser);

router.get("/register", controller.get);
router.post("/register", controller.registerUser);

router.get("/logout", controller.logout);

module.exports = router;
