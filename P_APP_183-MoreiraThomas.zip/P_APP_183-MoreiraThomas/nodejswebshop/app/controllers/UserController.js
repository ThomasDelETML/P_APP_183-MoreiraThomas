module.exports = {
  get: (req, res) => {
    if (!req.session.username) {
      return res.redirect("/login"); // Redirige si non connecté
    }
    res.render("user", { username: req.session.username });
  },
};
