// appel fichier config => la connexion à la base de données est établie
const db = require("../config/db");

module.exports = {
  checkUser: (req, res) => {
    console.log("Utilisateur identifié");
  },
  registerUser: async (req, res) => {
    console.log("Utilisateur enregistré");

    await pool.query("INSERT INTO users (email, password) VALUES (?, ?)", [
      req.body.email,
      req.body.password,
    ]);
  },

  get: (req, res) => {
    const page = req.path === "/register" ? "register" : "login";
    res.render(page, { name: "Thomas" });
  },
};
